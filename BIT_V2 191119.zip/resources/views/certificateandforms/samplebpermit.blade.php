

<div id="print_this" style="display: none">

<div class="panel-body" id="printBarangayBusinessPermint">lbl_or_number

		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;">Republic of the Philippines</p>
		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;">Province of Rizal</p>
		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;">Municipality of Tanay</p>
		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;"><strong>BARANGAY ____________________</strong></p>
		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;"><strong>&nbsp;</strong></p>
		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;">PAHINTULOT SA PANGANGALAKAL</p>
		<p style="text-align: center; margin-bottom: 1px; padding: -1px; font-size: large;">(BUSINESS PERMIT) </p>
		<p style="margin-bottom: 2px; padding: -2px; ">&nbsp;</p>
		<p style="margin-bottom: 2px; padding: -2px; font-size: large;">MATALASTAS NG LAHAT:</p>
		<p style="margin-bottom: 2px; padding: -2px; font-size: large;">(KNOW ALL MEN BY THERE PRESENTS)</p>
		<p style="margin-bottom: 2px; padding: -2px;">&nbsp;</p>
		<p style="margin-bottom: 2px; padding: -2px; font-size: large;">NA/SI/ANG:</p>
		<p style="margin-bottom: 2px; padding: -2px; font-size: large;">(THAT)</p>
		{{-- <p style="margin-bottom: 2px; padding: 2px;">&nbsp;</p> --}}
		{{-- <p style="margin-bottom: 2px; padding: 2px;">&nbsp;</p> --}}
		<p style="text-align: center; margin-bottom: 2px; padding: -2px; font-size: large;" id="lbl_company_name" name="lbl_company_name"><u></u></p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;" >&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; font-size: large; " >na matatagpuan at may pahatirang sulat sa</p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;font-size: large;">(with postal address at)</p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;">&nbsp;</p>
		<p style="text-align: center; margin-bottom: 2px;font-size: large;" id="lbl_business_address"  name="lbl_business_address"><u>(Address)</u></p>
		<p style="text-align: center; margin-bottom: 2px;font-size: large;">na itinatag nang may buong Karapatan at umiiral sa ilalim ng mga batas ng</p>
		<p style="text-align: center; margin-bottom: 2px;font-size: large;">(duly recognized and existing under the law of the)</p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;font-size: large;">Republika ng Pilipinas, ay pinagkalooban ng pahintulot na mangalakal bilang</p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;font-size: large;">(Republic of the Philippines, is hereby granted the permit to operate as)</p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;font-size: large;">&nbsp;</p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;font-size: large;" d="lbl_line_business" name="lbl_line_business"><u>(Line of Business)</u></p>
		<p style="text-align: center; margin-bottom: 2px; padding: -2px;font-size: large;">&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">Ngayong ika - <u>(araw)</u> ng <u>(buwan at taon)</u></p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px; font-size: large;">(on this)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; (day of)</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;">&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;">&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">Ang pahintulot na ito ay matatapos sa ika &ndash; 31 of December (YYYY)</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">(This permit expires on)</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;">&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">Malibang ito&rsquo;y maagang bawiin at pawalang bias.</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">(unless sooner revoked)</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;">&nbsp;</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">(PUNONG BARANGAY)</p>
		<p style="text-align: center;margin-bottom: 2px; padding: -2px;font-size: large;">Punong Barangay</p>
		<p>&nbsp;</p>
		<table style="width: 953px; border-color: #000; align-self: center;" border="1" align="center">
			<tbody>
				<tr style="height: 25px; font-size: large;">
					<td style="width: 78px; height: 25px; text-align: center;">
						<p>&nbsp;&nbsp;TAX YEAR</p>
					</td>
					<td style="width: 78px; height: 25px; text-align: center;">
						<p>&nbsp;&nbsp;(YYYY)</p>
					</td>
					<td style="width: 78px; height: 25px; text-align: center;">
						<p>&nbsp;&nbsp;QUARTER</p>
					</td>
					<td style="width: 78px; height: 25px; text-align: center;">
						<p>&nbsp;&nbsp;(QTR)</p>
					</td>
					<td style="width: 340px; height: 248px; padding-left: 2px;  " rowspan="8">
						<p style="padding: 5px"><strong>IMPORTANT</strong></p>
						<p style="padding: 5px">Failure to renew this Business Permit within the prescribed period shall subject the taxpayer to a twenty-five percent (25%) surcharge and two percent (2%) penalty per month.&nbsp; Upon closure of business, surrender this permit to Barangay Treasurer&rsquo;s Office on or before the twentieth (20<sup>th</sup>) day of the month following the quarter to avoid penalty.</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 78px; height: 25px; text-align: center;">
						<p>&nbsp;OR No.</p> <p id="lbl_or_number"> </p>
					</td>
					
					<td style="width: 78px; height: 31px; text-align: center;">
						<p>&nbsp;&nbsp;OR Date</p>
					</td>
					<td style="width: 78px; height: 31px; text-align: center;">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p style="text-align: left;">&nbsp;&nbsp;OR Amount:</p>
					</td>
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p style="text-align: left;">&nbsp;&nbsp;Barangay Permit</p>
					</td>
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p style="text-align: left;">&nbsp;&nbsp;Business Tax</p>
					</td>
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p style="text-align: left;">&nbsp;&nbsp;Garbage Fee</p>
					</td>
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p style="text-align: left;">&nbsp;&nbsp;Signboard</p>
					</td>
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 25px;">
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p style="text-align: left;">&nbsp;&nbsp;CTC</p>
					</td>
					<td style="width: 156px; height: 25px; text-align: center;" colspan="2">
						<p>&nbsp;</p>
					</td>
				</tr>
				<tr style="height: 101px;">
					<td style="width: 652px; height: 101px; text-align: center; font-size: large;" colspan="5">
						<p>ITO AY DAPAT IPASKIL SA HAYAG NA POOK NG KALAKALAN AT DAPAT IPAKITA SA SANDALING HINGIN NG MGA KINAUUKULANG MAYKAPANGYARIHAN.</p>
						<p style="text-align: center;">(THIS MUST BE POSTED ON CONSPICUOUS PLACE AND BE PRESENTED UPON DEMAND BY PROPER AUTHORITIES.)</p>
					</td>
				</tr>
			</tbody>
		</table>
		<p>&nbsp;</p>
	</div>
	</div>